#include "spi.h"

int spi_flag;

void spiInterruptHandler(void){
	spi_flag = 1;
	ackSPIInterrupt(SPI_INTR_ADDR);
	//printf("SPI Interrupt...\n");
}


void enableSPIInterrupt(void *baseAddr_p){
	u32 baseaddr;
	baseaddr = (u32)baseAddr_p;

	//enable interrupt
	SPI_INTR_mWriteReg(baseaddr,0x4,0x1);

	//enable global interrupt
	SPI_INTR_mWriteReg(baseaddr,0x0,0x1);

	// clear flag
	spi_flag = 0;
}


void ackSPIInterrupt(void *baseAddr_p){
	u32 baseaddr;
	baseaddr = (u32)baseAddr_p;

	// ack interrupt
	SPI_INTR_mWriteReg(baseaddr,0xc,0x1);
}


void setupSPIInterrupts(SPIinstance* SPIInst, XScuGic *INTCInst){
	XScuGic_Config *IntcConfig;
	int status = 0;

	// Interrupt controller initialization
	IntcConfig = XScuGic_LookupConfig(XPAR_PS7_SCUGIC_0_DEVICE_ID);
	status = XScuGic_CfgInitialize(INTCInst, IntcConfig,
			IntcConfig->CpuBaseAddress);
	if (status != XST_SUCCESS)
		printf("Failed to initialize interrupt controller... \n");

	// Call to interrupt setup
	Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_INT,
				(Xil_ExceptionHandler) XScuGic_InterruptHandler,
				INTCInst);
	Xil_ExceptionEnable();

	// Setup vector to interrupt handler
	status = XScuGic_Connect(INTCInst, XPAR_FABRIC_SPI_INTR_0_IRQ_INTR,
			(Xil_ExceptionHandler) spiInterruptHandler, (void *) SPIInst);
	if (status != XST_SUCCESS)
			printf("Failed to setup SPI interrupt... \n");

	// Enable SPI interrupts in the controller
	XScuGic_Enable(INTCInst, XPAR_FABRIC_SPI_INTR_0_IRQ_INTR);

	// Enable SPI interrupt
	enableSPIInterrupt(SPI_INTR_ADDR);
}


int getSPIFlag(void){
	return spi_flag;
}


int clearSPIFlag(void){
	spi_flag = 0;
	return spi_flag;
}


void SPIsendByte(char dataByte){
	SPI_INTR_mWriteReg(SPI_BASE_ADDR,SPI_TX,0x0);
	SPI_INTR_mWriteReg(SPI_BASE_ADDR,SPI_TX,0x100|(int)dataByte);
	while(getSPIFlag() == 0);
	clearSPIFlag();
	SPI_INTR_mWriteReg(SPI_BASE_ADDR,SPI_TX,0x0);
}


int SPIreadByte(void){
	SPI_INTR_mWriteReg(SPI_BASE_ADDR,SPI_TX,0x100);
	while(getSPIFlag() == 0);
	clearSPIFlag();
	SPI_INTR_mWriteReg(SPI_BASE_ADDR,SPI_TX,0x0);
	return SPI_INTR_mReadReg(SPI_BASE_ADDR,SPI_RX);
}

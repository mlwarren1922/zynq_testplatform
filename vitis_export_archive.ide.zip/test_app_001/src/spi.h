#include "spi_intr.h"
#include <stdio.h>
#include "xparameters.h"
#include "xscugic.h"
#include "xil_io.h"

typedef struct{
	UINTPTR BaseAddress;	/**< Device base address */
	u32 IsReady;		/**< Device is initialized and ready */
	int InterruptPresent;	/**< Are interrupts supported in h/w */
	int IsDual;		/**< Are 2 channels supported in h/w */
} SPIinstance;

// SPI INFO
#define SPI_BASE_ADDR		XPAR_SPI_INTR_0_S00_AXI_BASEADDR
#define SPI_DEVICE_ID		XPAR_SPI_INTR_0_DEVICE_ID
#define SPI_RX				SPI_INTR_S00_AXI_SLV_REG1_OFFSET
#define SPI_TX				SPI_INTR_S00_AXI_SLV_REG0_OFFSET
#define SPI_INTR_ADDR		0x43c40000 //from vivado addresses



void spiInterruptHandler(void);
void setupSPIInterrupts(SPIinstance* SPIInst, XScuGic *INTCInst);
int writeSPIData(u32 *data);
void enableSPIInterrupt(void *baseAddr_p);
void ackSPIInterrupt(void *baseAddr_p);

int getSPIFlag(void);
int clearSPIFlag(void);
void SPIsendByte(char dataByte);
int SPIreadByte(void);


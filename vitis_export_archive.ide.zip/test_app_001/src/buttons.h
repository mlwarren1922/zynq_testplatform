/*
 * buttons.h
 *
 *  Created on: Sep 29, 2023
 *      Author: engineer
 */

#ifndef SRC_BUTTONS_H_
#define SRC_BUTTONS_H_

#include <stdio.h>
#include "xgpio.h"
#include "xparameters.h"
#include "xscugic.h"

void setupBUTTONS(XGpio *BUTTONSInst,u16 deviceID);
void setupBUTTONSInterrupt(XGpio *BUTTONSInst,XScuGic *INTCInst);
void buttonIntHandler(void *BUTTONSInst);
int getButtonFlag(void);
void clearButton(int button);
void clearAllButtons(void);


#endif /* SRC_BUTTONS_H_ */

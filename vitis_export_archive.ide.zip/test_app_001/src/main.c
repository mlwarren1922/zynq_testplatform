#include "rgb_led_driver.h"
#include "led_controller.h"
#include "buttons.h"
#include "spi.h"
#include "xgpio.h"
#include "xscugic.h"
//#include "xparameters.h"
#include "xil_io.h"
#include <stdio.h>

// Define delay length
#define DELAY 100000000


// LED INFO
#define LED_BASE_ADDR 	XPAR_LED_CONTROLLER_0_S00_AXI_BASEADDR
#define LED_OFFSET		LED_CONTROLLER_S00_AXI_SLV_REG0_OFFSET

// RGB INFO
#define RGB0_BASE_ADDR	XPAR_RGB_LED_DRIVER_0_S00_AXI_BASEADDR
#define RGB1_BASE_ADDR  XPAR_RGB_LED_DRIVER_1_S00_AXI_BASEADDR
#define RED_OFFSET		RGB_LED_DRIVER_S00_AXI_SLV_REG0_OFFSET
#define GREEN_OFFSET	RGB_LED_DRIVER_S00_AXI_SLV_REG1_OFFSET
#define BLUE_OFFSET		RGB_LED_DRIVER_S00_AXI_SLV_REG2_OFFSET

// Buttons INFO
#define BUTTON_BASE_ADDR	XPAR_AXI_BUTTONS_0_BASEADDR
#define BUTTON_DEVICE_ID	XPAR_AXI_BUTTONS_0_DEVICE_ID
#define BUTTON_INT_PR		XPAR_AXI_BUTTONS_0_INTERRUPT_PRESENT
#define BUTTON_IS_DUAL		XPAR_AXI_BUTTONS_0_IS_DUAL
XGpio BTNInst;


SPIinstance SPIInst;
XScuGic INTCInst;

#define LED_LIMIT 100000000
#define RGB_VALUE 63



int main(void){
	/* unsigned 32-bit variables for storing current LED value */
		u32 led_val = 0xa5;
		int i = 0;

		//Setup Buttons
		BTNInst.BaseAddress = BUTTON_BASE_ADDR;
		BTNInst.InterruptPresent = XPAR_AXI_BUTTONS_0_INTERRUPT_PRESENT;
		BTNInst.IsDual = BUTTON_IS_DUAL;
		setupBUTTONS(&BTNInst,BUTTON_DEVICE_ID);
		setupBUTTONSInterrupt(&BTNInst,&INTCInst);

		//Setup SPI
		SPIInst.BaseAddress = SPI_BASE_ADDR;
		SPIInst.InterruptPresent = 1;
		SPIInst.IsDual = 0;
		setupSPIInterrupts(&SPIInst,&INTCInst);


		RGB_LED_DRIVER_mWriteReg(RGB0_BASE_ADDR,RED_OFFSET,63);
		RGB_LED_DRIVER_mWriteReg(RGB0_BASE_ADDR,GREEN_OFFSET,0);
		RGB_LED_DRIVER_mWriteReg(RGB0_BASE_ADDR,BLUE_OFFSET,0);
		RGB_LED_DRIVER_mWriteReg(RGB1_BASE_ADDR,RED_OFFSET,0);
		RGB_LED_DRIVER_mWriteReg(RGB1_BASE_ADDR,GREEN_OFFSET,0);
		RGB_LED_DRIVER_mWriteReg(RGB1_BASE_ADDR,BLUE_OFFSET,63);

		//main loop
		while(1){
			led_val = getButtonFlag();
			LED_CONTROLLER_mWriteReg(LED_BASE_ADDR,LED_OFFSET,led_val);
			if(led_val != 0){
				for(i=0;i<=DELAY;i++);
				i = SPIreadByte();
				printf("Status Reg: %x \n",i);
				clearAllButtons();
			}
		}

		return 1;
}

/*
 * buttons.c
 *
 *  Created on: Sep 29, 2023
 *      Author: engineer
 */

#include "buttons.h"

int buttonFlag;


void buttonIntHandler(void *BUTTONSInst){
	int data = 0;
	//Disable interrupt
	XGpio_InterruptDisable(BUTTONSInst, 1);
	data = XGpio_DiscreteRead(BUTTONSInst,1);
	printf("Button Pressed... data= %x, flag= %x\n", data,buttonFlag);
	buttonFlag = data | buttonFlag;
	XGpio_InterruptClear(BUTTONSInst, 1);
	XGpio_InterruptEnable(BUTTONSInst, 1);
}

void setupBUTTONS(XGpio *BUTTONSInst,u16 deviceID){
	XGpio_Initialize(BUTTONSInst,deviceID);
	XGpio_SetDataDirection(BUTTONSInst,1,0xFF);
	buttonFlag = 0;
}

void setupBUTTONSInterrupt(XGpio *BUTTONSInst,XScuGic *INTCInst){
	XScuGic_Config *IntcConfig;
	int status = 0;

	// Interrupt controller initialization
	IntcConfig = XScuGic_LookupConfig(XPAR_PS7_SCUGIC_0_DEVICE_ID);
	status = XScuGic_CfgInitialize(INTCInst, IntcConfig,
			IntcConfig->CpuBaseAddress);
	if (status != XST_SUCCESS)
		printf("Failed to initialize interrupt controller... \n");

	// Call to interrupt setup
	XGpio_InterruptEnable(BUTTONSInst, 1);
	XGpio_InterruptGlobalEnable(BUTTONSInst);

	Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_INT,
			(Xil_ExceptionHandler) XScuGic_InterruptHandler,
			INTCInst);
	Xil_ExceptionEnable();

	// Connect GPIO interrupt to handler
	status = XScuGic_Connect(INTCInst, XPAR_FABRIC_AXI_BUTTONS_0_IP2INTC_IRPT_INTR,
			(Xil_ExceptionHandler) buttonIntHandler, (void *) BUTTONSInst);
	if (status != XST_SUCCESS)
		printf("Failed to setup GPIO interrupt... \n");

	// Enable GPIO interrupts interrupt
	XGpio_InterruptEnable(BUTTONSInst, 1);
	XGpio_InterruptGlobalEnable(BUTTONSInst);

	// Enable GPIO and timer interrupts in the controller
	XScuGic_Enable(INTCInst, XPAR_FABRIC_AXI_BUTTONS_0_IP2INTC_IRPT_INTR);
}

int getButtonFlag(void){
	return buttonFlag;
}

void clearButtonFlag(int button){
	buttonFlag = ~button & buttonFlag;
}

void clearAllButtons(void){
	buttonFlag = 0;
}



/***************************** Include Files *******************************/
#include "spi_intr.h"

/************************** Function Definitions ***************************/

//void enableSPIInterrupt(void *baseAddr_p){
//	u32 baseaddr;
//	baseaddr = (u32)baseAddr_p;
//
//	//enable interrupt
//	SPI_INTR_mWriteReg(baseaddr,0x4,0x1);
//
//	//enable global interrupt
//	SPI_INTR_mWriteReg(baseaddr,0x0,0x1);
//}


//void ackSPIInterrupt(void *baseAddr_p){
//	u32 baseaddr;
//	baseaddr = (u32)baseAddr_p;
//
//	// ack interrupt
//	SPI_INTR_mWriteReg(baseaddr,0xc,0x1);
//}
